This folder containsa dataset for the model
